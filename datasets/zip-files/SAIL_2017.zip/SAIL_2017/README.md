# SAIL 2017 Dataset

This dataset has been taken from [SAIL 2017 Competition](http://www.dasdipankar.com/SAILCodeMixed.html)
