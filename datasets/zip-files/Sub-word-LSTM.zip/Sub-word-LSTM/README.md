# Sub-word LSTM

You can find this datset in this [git repo](https://github.com/drimpossible/Sub-word-LSTM).  
Citation info

```latex
Towards Sub-Word Level Compositions for Sentiment Analysis of Hi-En Code Mixed Text, COLING 2016.

Ameya Prabhu*, Aditya Joshi*, Manish Shrivastava and Vasudeva Verma
(* indicating equal contribution)


@article{prabhu2016subword,
  title={Towards Sub-Word Level Compositions for Sentiment Analysis of Hindi-English Code Mixed Text},
  author={Prabhu, Ameya, Joshi, Aditya, Shrivastava, Manish and Verma, Vasudeva},
  journal={arXiv preprint arXiv:1611.00472},
  year={2016}
}
```
