# CS-EN-ES-CORPUS

You can find the dataset [here](http://www.grupolys.org/software/CS-CORPORA/cs-en-es-corpus-wassa2015.txt).  
I preprocessed the data with the help of a script by Microsoft research [here](https://github.com/microsoft/GLUECoS/blob/master/Data/Preprocess_Scripts/preprocess_sent_en_es.py).
Citation info

```text
Vilares, David and Alonso, Miguel A. and Gómez-Rodríguez, Carlos, "Sentiment Analysis on Monolingual, MultiLingual and Code-Switching Twitter Corpora", in 6th Workshop on Computational Approaches to Subjectivity, Sentiment & Social Media Analysis (WASSA 2015), Lisbon, Portugal, 2015
```
